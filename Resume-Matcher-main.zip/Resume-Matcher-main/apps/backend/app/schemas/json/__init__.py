from .base import JSONSchemaFactory

json_schema_factory = JSONSchemaFactory()
__all__ = ["json_schema_factory"]
