# Responsible Disclosure

## Reporting a Vulnerability

Resume-Matcher strives to stay ahead of security vulnerabilities but would love to get the community's help in making us aware of the ones we miss.

Please contact a maintainer to report security vulnerabilities and exploits.

We will acknowledge legitimate reports and address them according to their severity.
